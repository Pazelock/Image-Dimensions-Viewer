# SPDX-License-Identifier: GPL-2.0-or-later
#
# Image Dimensions Viewer
# Copyright (C) 2025 Pazelock
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

bl_info = {
    "name": "Image Dimensions Viewer",
    "author": "Pazelock",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "category": "User Interface",
    "website": "https://extensions.blender.org/add-ons/image-dimensions-viewer",
    "tracker_url": "https://github.com/pazelock/image-dimensions-viewer/issues",
    "doc_url": "https://github.com/Pazelock/Image-Dimensions-Viewer/blob/main/docs/GUIDE.md",
}

import bpy
import blf
import gpu
import math
from gpu_extras.batch import batch_for_shader


# ─────────────────────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _get_prefs():
    return bpy.context.preferences.addons[__package__].preferences


def _draw_rounded_rect(x, y, w, h, r, color):
    """Filled rounded rectangle via triangle fan."""
    r = min(r, w * 0.5, h * 0.5)
    if r < 0:
        r = 0
    segs = max(4, int(r * 2))
    PI = math.pi

    def _arc(cx, cy, radius, a0, a1, n):
        if n == 0:
            return [(cx + math.cos(a0) * radius, cy + math.sin(a0) * radius)]
        return [
            (cx + math.cos(a0 + (a1 - a0) * i / n) * radius,
             cy + math.sin(a0 + (a1 - a0) * i / n) * radius)
            for i in range(n + 1)
        ]

    outline = (
        _arc(x + r,     y + r,     r, PI,        1.5 * PI, segs) +
        _arc(x + w - r, y + r,     r, 1.5 * PI,  2.0 * PI, segs) +
        _arc(x + w - r, y + h - r, r, 0.0,        0.5 * PI, segs) +
        _arc(x + r,     y + h - r, r, 0.5 * PI,  PI,        segs)
    )

    cx = x + w * 0.5
    cy = y + h * 0.5
    n = len(outline)
    tris = []
    for i in range(n):
        tris += [(cx, cy), outline[i], outline[(i + 1) % n]]

    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRIS', {"pos": tris})
    gpu.state.blend_set('ALPHA')
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set('NONE')


def _get_zoom(view2d):
    """Return pixels-per-view-unit for the given View2D.
    We convert two *region* pixels that are 1px apart back to view-space,
    measure the view-unit distance, then invert — immune to pan position."""
    vx0, vy0 = view2d.region_to_view(0, 0)
    vx1, vy1 = view2d.region_to_view(1, 0)
    view_units_per_px = math.hypot(vx1 - vx0, vy1 - vy0)
    if view_units_per_px < 1e-9:
        return 1.0
    return 1.0 / view_units_per_px  # px per view-unit


def _draw_label(label, rx, ry, font_id, font_size, pad, radius, bg, fg):
    """Draw background box + text. (rx, ry) = top-left anchor in screen px."""
    blf.size(font_id, font_size)
    tw, th = blf.dimensions(font_id, label)
    bw = tw + pad * 2
    bh = th + pad * 2
    bx = rx
    by = ry - bh
    _draw_rounded_rect(bx, by, bw, bh, radius, bg)
    blf.color(font_id, *fg)
    blf.position(font_id, bx + pad, by + pad, 0)
    blf.draw(font_id, label)


# ─────────────────────────────────────────────────────────────────────────────
#  Node Editor draw callback
# ─────────────────────────────────────────────────────────────────────────────

def _draw_node_editor():
    ctx = bpy.context
    space = getattr(ctx, 'space_data', None)
    if space is None or space.type != 'NODE_EDITOR':
        return
    if not space.overlay.show_overlays:
        return
    scene = getattr(ctx, 'scene', None)
    if scene is None or not scene.idv_node_show:
        return
    # Use edit_tree so the display updates when entering a node group.
    # edit_tree reflects the currently active (possibly nested) tree,
    # while node_tree always points to the root tree.
    node_tree = space.edit_tree
    if node_tree is None:
        return
    region = ctx.region
    if region is None or region.type != 'WINDOW':
        return

    view2d = region.view2d
    prefs  = _get_prefs()

    # pixels-per-node-unit, pan-independent
    zoom = _get_zoom(view2d)

    # Prefs are in node-units; multiply by zoom → screen pixels.
    s         = zoom
    font_size = max(1, round(prefs.node_font_size * s))
    pad       = max(0, round(prefs.node_padding   * s))
    radius    = max(0, round(prefs.node_corner_radius * s))
    offset_x  = prefs.node_offset_x  # node-units
    offset_y  = prefs.node_offset_y  # node-units

    font_id = 0
    bg = tuple(prefs.node_bg_color)
    fg = tuple(prefs.node_text_color)

    for node in node_tree.nodes:
        if node.type != 'TEX_IMAGE':
            continue
        if node.hide:
            continue
        img = node.image
        if img is None:
            continue
        w_px, h_px = img.size
        if w_px == 0 and h_px == 0:
            continue

        label = f"{w_px} \u00d7 {h_px} px"

        # node.location = top-left in node-space. Apply X/Y offsets (node-units).
        vx = node.location.x + offset_x
        vy = node.location.y + offset_y
        rx, ry = view2d.view_to_region(vx, vy, clip=False)

        # Cull nodes far off-screen
        if rx < -800 or ry < -400 or rx > region.width + 400 or ry > region.height + 400:
            continue

        _draw_label(label, rx, ry, font_id, font_size, pad, radius, bg, fg)


# ─────────────────────────────────────────────────────────────────────────────
#  Image Editor draw callback
# ─────────────────────────────────────────────────────────────────────────────

def _draw_image_editor():
    ctx = bpy.context
    space = getattr(ctx, 'space_data', None)
    if space is None or space.type != 'IMAGE_EDITOR':
        return
    if not space.overlay.show_overlays:
        return
    scene = getattr(ctx, 'scene', None)
    if scene is None or not scene.idv_image_show:
        return
    img = space.image
    if img is None:
        return
    w_px, h_px = img.size
    if w_px == 0 and h_px == 0:
        return
    region = ctx.region
    if region is None or region.type != 'WINDOW':
        return

    view2d = region.view2d
    prefs  = _get_prefs()

    # Image Editor: fixed screen pixels, no zoom scaling
    font_id   = 0
    font_size = prefs.ie_font_size
    pad       = prefs.ie_padding
    radius    = prefs.ie_corner_radius
    offset    = prefs.ie_offset
    origin    = prefs.ie_origin  # 'BELOW' or 'ABOVE'
    bg        = tuple(prefs.ie_bg_color)
    fg        = tuple(prefs.ie_text_color)

    label = f"{w_px} × {h_px} px"

    blf.size(font_id, font_size)
    tw, th = blf.dimensions(font_id, label)
    bw = tw + pad * 2
    bh = th + pad * 2

    # Image spans UV [0,1]x[0,1].
    # BELOW: anchor centred just below the bottom edge (UV y=0).
    # ABOVE: anchor centred just above the top edge (UV y=1).
    if origin == 'BELOW':
        cx_px, cy_px = view2d.view_to_region(0.5, 0.0, clip=False)
        bx = cx_px - bw * 0.5
        by = cy_px - offset - bh
    else:  # ABOVE
        cx_px, cy_px = view2d.view_to_region(0.5, 1.0, clip=False)
        bx = cx_px - bw * 0.5
        by = cy_px + offset

    _draw_rounded_rect(bx, by, bw, bh, radius, bg)
    blf.color(font_id, *fg)
    blf.position(font_id, bx + pad, by + pad, 0)
    blf.draw(font_id, label)


# ─────────────────────────────────────────────────────────────────────────────
#  Overlay checkbox injection
# ─────────────────────────────────────────────────────────────────────────────

# Node Editor: IMAGE_PT_overlay has real content in draw(), so append() puts
# our checkbox after the built-in items — no gap, correct order.
def _node_overlay_draw(self, context):
    self.layout.prop(context.scene, "idv_node_show", text="Image Dimensions")


# Image Editor: IMAGE_PT_overlay has draw(): pass — all content is in child
# sub-panels. The single existing checkbox lives in IMAGE_PT_overlay_image,
# so we append directly onto that panel. This puts our checkbox immediately
# after the built-in one with no gap and no extra sub-panel separator.
def _image_overlay_draw(self, context):
    self.layout.prop(context.scene, "idv_image_show", text="Image Dimensions")


# ─────────────────────────────────────────────────────────────────────────────
#  Add-on Preferences
# ─────────────────────────────────────────────────────────────────────────────

class ImageDimensionsPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    # ── Node Editor (values in node-units, scaled by zoom at draw time) ──────
    node_font_size: bpy.props.IntProperty(
        name="Font Size", default=12, min=1, max=500,
        description="Label font size in node-units (scales with zoom)")
    node_padding: bpy.props.IntProperty(
        name="Padding", default=3, min=0, max=500,
        description="Inner padding of the label box in node-units")
    node_corner_radius: bpy.props.IntProperty(
        name="Corner Radius", default=3, min=0, max=500,
        description="Corner radius of the label box in node-units")
    node_offset_x: bpy.props.IntProperty(
        name="X Offset", default=0, min=-500, max=500,
        description="Horizontal offset from the node top-left corner in node-units")
    node_offset_y: bpy.props.IntProperty(
        name="Y Offset", default=25, min=-500, max=500,
        description="Vertical offset from the node top-left corner in node-units")
    node_bg_color: bpy.props.FloatVectorProperty(
        name="Background Color", subtype='COLOR_GAMMA', size=4,
        default=(0.0, 0.0, 0.0, 0.6), min=0.0, max=1.0)
    node_text_color: bpy.props.FloatVectorProperty(
        name="Text Color", subtype='COLOR_GAMMA', size=4,
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0)

    # ── Image Editor (fixed screen pixels) ───────────────────────────────────
    ie_font_size: bpy.props.IntProperty(
        name="Font Size", default=12, min=1, max=500,
        description="Label font size in screen pixels (does not scale with zoom)")
    ie_padding: bpy.props.IntProperty(
        name="Padding", default=5, min=0, max=500,
        description="Inner padding of the label box in screen pixels")
    ie_corner_radius: bpy.props.IntProperty(
        name="Corner Radius", default=5, min=0, max=500,
        description="Corner radius of the label box in screen pixels")
    ie_offset: bpy.props.IntProperty(
        name="Offset", default=5, min=-1000, max=1000,
        description="Gap between the image edge and the label box in screen pixels")
    ie_origin: bpy.props.EnumProperty(
        name="Origin",
        description="Whether the label appears below or above the image",
        items=[
            ('BELOW', "Below", "Place label below the bottom edge of the image"),
            ('ABOVE', "Above", "Place label above the top edge of the image"),
        ],
        default='BELOW',
    )
    ie_bg_color: bpy.props.FloatVectorProperty(
        name="Background Color", subtype='COLOR_GAMMA', size=4,
        default=(0.0, 0.0, 0.0, 0.6), min=0.0, max=1.0)
    ie_text_color: bpy.props.FloatVectorProperty(
        name="Text Color", subtype='COLOR_GAMMA', size=4,
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0)

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Node Editor Overlay", icon='NODETREE')
        col = box.column(align=True)
        col.prop(self, "node_font_size")
        col.prop(self, "node_padding")
        col.prop(self, "node_corner_radius")
        row = col.row(align=True)
        row.prop(self, "node_offset_x")
        row.prop(self, "node_offset_y")
        col.prop(self, "node_bg_color")
        col.prop(self, "node_text_color")

        box = layout.box()
        box.label(text="Image Editor Overlay", icon='IMAGE')
        col = box.column(align=True)
        col.prop(self, "ie_font_size")
        col.prop(self, "ie_padding")
        col.prop(self, "ie_corner_radius")
        col.prop(self, "ie_offset")
        col.prop(self, "ie_origin")
        col.prop(self, "ie_bg_color")
        col.prop(self, "ie_text_color")


# ─────────────────────────────────────────────────────────────────────────────
#  Handler management
# ─────────────────────────────────────────────────────────────────────────────

_handles = {}


def _register_handlers():
    _handles['node'] = bpy.types.SpaceNodeEditor.draw_handler_add(
        _draw_node_editor, (), 'WINDOW', 'POST_PIXEL')
    _handles['image'] = bpy.types.SpaceImageEditor.draw_handler_add(
        _draw_image_editor, (), 'WINDOW', 'POST_PIXEL')


def _unregister_handlers():
    h = _handles.pop('node', None)
    if h:
        bpy.types.SpaceNodeEditor.draw_handler_remove(h, 'WINDOW')
    h = _handles.pop('image', None)
    if h:
        bpy.types.SpaceImageEditor.draw_handler_remove(h, 'WINDOW')


# ─────────────────────────────────────────────────────────────────────────────
#  Register / Unregister
# ─────────────────────────────────────────────────────────────────────────────

classes = (
    ImageDimensionsPreferences,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.idv_node_show = bpy.props.BoolProperty(
        name="Image Dimensions",
        description="Show image dimensions on Image Texture nodes in the Node Editor",
        default=True,
    )
    bpy.types.Scene.idv_image_show = bpy.props.BoolProperty(
        name="Image Dimensions",
        description="Show image dimensions overlay in the Image Editor",
        default=True,
    )

    bpy.types.NODE_PT_overlay.append(_node_overlay_draw)
    bpy.types.IMAGE_PT_overlay_image.append(_image_overlay_draw)

    _register_handlers()


def unregister():
    _unregister_handlers()

    bpy.types.NODE_PT_overlay.remove(_node_overlay_draw)
    bpy.types.IMAGE_PT_overlay_image.remove(_image_overlay_draw)

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.idv_node_show
    del bpy.types.Scene.idv_image_show
